 #include <iostream>
 #include <string>


 int main()
 {
	std::string name;
	std::cout << "Insert name:" << endl;
	std::cin >> name
 	std::cout << "Hello, " << name << "." << std::endl;


	// Menisköhä tää harkkatyönä läpi...
 }
