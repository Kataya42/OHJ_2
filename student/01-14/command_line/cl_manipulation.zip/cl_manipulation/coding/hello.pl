print "Hello World\n"
